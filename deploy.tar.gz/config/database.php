<?php
class Database {
    private $host = '45.84.205.180';
    private $db_name = 'u914327722_insta_lite';
    private $username = 'u914327722_root';
    private $password = '1234567890MKERTaz';
    
    public function getConnection() {
        try {
            $conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch(PDOException $e) {
            echo "Connection Error: " . $e->getMessage();
            return null;
        }
    }
}
