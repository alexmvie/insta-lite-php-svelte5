<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HTMX + Alpine.js Demo</title>
    <script src="https://unpkg.com/htmx.org@1.9.10"></script>
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-2xl mx-auto">
        <h1 class="text-3xl font-bold mb-8">HTMX + Alpine.js Demo</h1>

        <!-- Task List Container -->
        <div class="bg-white p-6 rounded-lg shadow-md">
            <div x-data="taskManager()">
                <div class="mb-4">
                    <input type="text" 
                           x-model="newTask" 
                           @keydown.enter="addTask"
                           placeholder="Add a new task..."
                           class="w-full px-4 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Tasks List -->
                <div class="space-y-4">
                    <template x-for="task in tasks" :key="task.id">
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded">
                            <div class="flex-1">
                                <input type="checkbox"
                                       x-model="task.completed"
                                       @change="updateTask(task)"
                                       class="mr-2">
                                <span x-text="task.title" 
                                      class="text-gray-800"
                                      :class="{ 'line-through text-gray-500': task.completed }">
                                </span>
                            </div>
                            <button @click="deleteTask(task.id)"
                                    class="text-red-500 hover:text-red-700">
                                Delete
                            </button>
                        </div>
                    </template>
                </div>
            </div>
        </div>
    </div>

    <script>
    function taskManager() {
        return {
            tasks: [],
            newTask: '',

            init() {
                this.fetchTasks();
            },

            async fetchTasks() {
                try {
                    const response = await fetch('api/tasks.php');
                    const result = await response.json();
                    if (result.success) {
                        this.tasks = result.data;
                    } else {
                        console.error('Error fetching tasks:', result.error);
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            },

            async addTask() {
                if (!this.newTask.trim()) return;
                
                try {
                    const response = await fetch('api/tasks.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ title: this.newTask })
                    });

                    const result = await response.json();
                    if (result.success) {
                        this.newTask = '';
                        this.fetchTasks();
                    } else {
                        console.error('Error adding task:', result.error);
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            },

            async updateTask(task) {
                try {
                    const response = await fetch(`api/tasks.php?id=${task.id}`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ completed: task.completed })
                    });

                    const result = await response.json();
                    if (!result.success) {
                        console.error('Error updating task:', result.error);
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            },

            async deleteTask(id) {
                if (!confirm('Are you sure you want to delete this task?')) return;

                try {
                    const response = await fetch(`api/tasks.php?id=${id}`, {
                        method: 'DELETE'
                    });

                    const result = await response.json();
                    if (result.success) {
                        this.fetchTasks();
                    } else {
                        console.error('Error deleting task:', result.error);
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            }
        }
    }
    </script>
</body>
</html>
